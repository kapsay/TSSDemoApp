﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TSS.Web.Models;

namespace WebApplication6.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {

            TSSDatabaseContext context = HttpContext.RequestServices.GetService(typeof(TSSDatabaseContext)) as TSSDatabaseContext;

            List<Link> links = new List<Link>(); 
            try
            {
                links = context.GetAllLinks();
            }
            catch
            {               
            }

            return View(links);
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
