﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TSS.Web.Models
{
    public class TSSDatabaseContext
    {
        public string ConnectionString { get; set; }

        public TSSDatabaseContext(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(ConnectionString);
        }

        public List<Link> GetAllLinks()
        {
            List<Link> list = new List<Link>();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM Link_Demo", conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Link()
                        {

                            Name = reader.GetString("LINK_NAME"),
                            Category = reader.GetString("LINK_CATEGORY"),
                            URL = reader.GetString("LINK_VALUE")

                        });
                    }
                }
            }

            return list;
        }

    }
}
